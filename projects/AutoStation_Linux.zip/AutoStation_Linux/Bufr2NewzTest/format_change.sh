export LD_LIBRARY_PATH=$(pwd)/..lib:$LD_LIBRARY_PATH
rm format_change
g++ -pthread -o format_change main.cpp    -L../lib -lbufr2newzlib  -lbufr
ldd format_change
./format_change
