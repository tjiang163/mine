#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include "../include/bufr.h"
#include <math.h>
#include <string.h>
#include "../include/MyBufr.h"
#include <iostream>
#include "../include/bufr2newzlib.h"
#include <pthread.h>
#include <sys/inotify.h>
#include <sys/stat.h>
#include <vector>

using namespace std;

#define BUF_LEN 1000
static vector<string> file_list;//用来保存文件列表
#define EVENT_NUM 12
#define SRCPATH "/test1/Bufr2NewzTest/"
#define SRCPATHFILES "/test1/Bufr2NewzTest/*"
/*
char *event_str[EVENT_NUM] =
{
	"IN_ACCESS",
	"IN_MODIFY",
	"IN_ATTRIB",
	"IN_CLOSE_WRITE",
	"IN_CLOSE_NOWRITE",
	"IN_OPEN",
	"IN_MOVED_FROM",
	"IN_MOVED_TO",
	"IN_CREATE",
	"IN_DELETE",
	"IN_DELETE_SELF",
	"IN_MOVE_SELF"
};
*/
//linux 创建多级目录
/* del by jt 20191016
int CreateDir(const char *sPathName)  
{  
	char DirName[256];  
	strcpy(DirName,sPathName);  
	int i,len = strlen(DirName);

	if(DirName[len-1]!='/')  
		strcat(DirName,"/");  

	len = strlen(DirName);  

	for(i=1;i<len;i++)  
	{  
		if(DirName[i]=='/')  
		{  
			DirName[i] = 0;  
			if( access(DirName, NULL)!=0 )  
			{  
				if(mkdir(DirName,0755)==-1)  
				{   
					perror("mkdir   error");   
					return   -1;   
				}  
			}  
			DirName[i] = '/';  
		}  
	}  

	return 0;  
}
*/

//辐射的线程封装函数
void Get_Process_radi_data(char * fileNamePath)
{
	if (NULL == fileNamePath)
		return;

	/*开辟较大的空间，因为有的打包文件有100多个站,如果再不够，再加大一点*/
	char 	dataValue[200000] = "";
	int   	dataLength = 0;
	int    	ret = 0;
	char* 	testName = "";
	char 	txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;

	testName = strstr(fileNamePath, "Z_RADI");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);


	memset(dataValue, 0, sizeof(dataValue));

	get_radi_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);

	outFile << dataValue << endl;

	outFile.close();

	//bufr.DebugRadi();
   //printf("the  radi_ dataValue is: %s \n", dataValue);
	return;
}

//酸雨的线程封装函数
void Get_Process_acidRain_data(char* fileNamePath)//
{
	if (NULL == fileNamePath)
		return;
	char s_FullPath[255];
	/*开辟较大的空间，因为有的打包文件有100多个站,如果再不够，再加大一点*/
	char	dataValue[200000] = "";
	int 	dataLength = 0;
	int 	ret = 0;
	char*	testName = "";
	char	txtName[512] = { 0 };
	string	fileOutName = "";
	fstream  outFile;

	testName = strstr(fileNamePath, "Z_CAWN");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);

	memset(dataValue, 0, sizeof(dataValue));
	memset(s_FullPath, 0, sizeof(s_FullPath));
	get_acidRain_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);
	/*
	strcpy(s_FullPath, sDesPath);
	strcat(s_FullPath, fileName);

	get_acidRain_value(s_FullPath, dataValue, sizeof(dataValue), &dataLength);
	*/
	outFile << dataValue << endl;

	outFile.close();

	//printf("the acidRain dataValue is: %s \n", dataValue);
	return;
}

//雨量的线程封装函数
void* Get_Process_rainFall_hour_data(void * arg)
{
	char dataValue[10240] = "";
	char fileName[512] = "../niel/Z_SURF_I_56399_20171226000000_O_AWS_FTM_PQC.BIN";
	int    dataLength;

	memset(dataValue, 0, sizeof(dataValue));

	get_rainFall_hour_value(fileName, dataValue, sizeof(dataValue), &dataLength);

	printf("the rainFall_hour dataValue is: %s \n", dataValue);
	return ((void*)0);
}

void* Get_Process_rainFall_minute_data(void * arg)
{
	char dataValue[10240] = "";
	char fileName[512] = "../niel/Z_SURF_I_56399_20171226001000_O_AWS-MM_FTM_PQC.BIN";
	int    dataLength;

	memset(dataValue, 0, sizeof(dataValue));

	get_rainFall_minute_value(fileName, dataValue, sizeof(dataValue), &dataLength);

	printf("the rainFall_minute dataValue is: %s \n", dataValue);
	return ((void*)0);
}


//地面小时BUFR--Z
void Get_Process_surf_hour_add_min_data(char * fileNamePath)
{

	if (NULL == fileNamePath)
		return;

	char 	dataValue[12048] = "";
	int   	dataLength = 0;
	int    	ret = 0;
	char* 	testName = "";
	char 	txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;

	testName = strstr(fileNamePath, "Z_SURF");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);

	memset(dataValue, 0, sizeof(dataValue));

	ret = get_sufr_hour_add_min_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);
	if (ret != 0)
		printf("error is get_sufr_hour_add_min_value \n");

	outFile << dataValue << endl;

	outFile.close();

	//printf("the sufr_hour dataValue is: %s \n", dataValue);
	return;
}

//地面小时BUFR--Z
void Get_Process_surf_hour_data(char * fileName, char* sDesPath)//fileNamePath
{
	if (NULL == fileName)
		return;

	char s_FullPath[255];
	char 	dataValue[200000] = "";   /*开辟较大的空间，因为有的打包文件有140多个站,如果再不够，再加大一点*/
	int   	dataLength = 0;
	int    	ret = 0;
	char* 	testName = "";
	char 	txtName[512] = { 0 };
	char s_OutPutFullPath[1024]={0};//输出文件完整路径

	string  fileOutName = "";
	fstream  outFile;

	testName = strstr(fileName, "Z_SURF");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;
	strcpy(s_OutPutFullPath,sDesPath);
	strcat(s_OutPutFullPath,txtName);
	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	//outFile.open(txtName, ios::out);
	outFile.open(s_OutPutFullPath, ios::out);//add by jt 20191016

	memset(dataValue, 0, sizeof(dataValue));
	cout <<fileName<<endl;
	ret = get_surf_hour_simple_value(fileName, dataValue, sizeof(dataValue), &dataLength);
	
	if (ret != 0)
		printf("error is get_surf_hour_simple_value \n");

	outFile << dataValue << endl;

	outFile.close();

	//printf("the sufr_hour dataValue is: %s \n", dataValue);
	return;
}


//地面分钟的线程封装函数
void  Get_Process_sufr_minute_data(char * fileNamePath)
{

	if (NULL == fileNamePath)
		return;

	/*开辟较大的空间，因为有的打包文件有190多个站,如果再不够，再加大一点*/
	char 	dataValue[250000] = "";
	int   	dataLength = 0;
	int    	ret = 0;
	char* 	testName = "";
	char 	txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;

	testName = strstr(fileNamePath, "Z_SURF");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);

	memset(dataValue, 0, sizeof(dataValue));

	ret = get_sufr_minute_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);
	if (ret != 0)
		printf("error is get_sufr_minute_value \n");

	outFile << dataValue << endl;

	outFile.close();

	//printf("the sufr_hour dataValue is: %s \n", dataValue);
	return;
}


//日照的线程封装函数
void Get_Process_sunLight_data(char * fileNamePath)
{
	if (NULL == fileNamePath)
		return;

	char dataValue[12048] = "";
	char* testName = "";
	char txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;


	testName = strstr(fileNamePath, "Z_SURF");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);


	int    dataLength;

	memset(dataValue, 0, sizeof(dataValue));

	get_sunLight_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);

	outFile << dataValue << endl;

	outFile.close();

	//printf("the dataValue is: %s", dataValue);
	//bufr.DebugSunLight();	
	return;
}


//高空L波段的线程封装函数.-50表示只保证500hpa以上的值。500hpa以下的不是全部有。
void Get_Process_upar_data(char * fileNamePath)
{
	if (NULL == fileNamePath)
		return;

	char dataValue[12048] = "";
	char* testName = "";
	char txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;


	testName = strstr(fileNamePath, "Z_UPAR");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);

	int    dataLength;

	memset(dataValue, 0, sizeof(dataValue));

	get_upar_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);

	outFile << dataValue << endl;

	outFile.close();

	//printf("the dataValue is: %s", dataValue);

}

//高空探风线程封装函数。
void* Get_Process_pilot_data(void * arg)
{
	char dataValue[12048] = "";

	//char fileName[512]   = "../niel/Z_UPAR_I_58847_20170228171529_O_PILOT-L-00_17022818.BIN";	
	char fileName[512] = "../niel/Z_UPAR_I_51463_20180318181214_O_PILOT-L-00_18031818_PQC.BIN";

	int    dataLength;

	memset(dataValue, 0, sizeof(dataValue));

	get_pilot_value(fileName, dataValue, sizeof(dataValue), &dataLength);

	//printf("the dataValue is: %s", dataValue);
	return ((void*)0);
}

//bufr转TAC，地面小时的测试接口用的测试函数
void  Get_tac_sufr_hour_data(char * fileNamePath)
{
	if (NULL == fileNamePath)
		return;

	int 	dataLength = 0;
	int 	ret = 0;
	char 	dataValue[12048] = "";
	char* 	testName = "";
	char 	txtName[512] = { 0 };
	string  fileOutName = "";
	fstream  outFile;

	testName = strstr(fileNamePath, "Z_SURF");
	fileOutName = testName;
	fileOutName = fileOutName.replace(fileOutName.find("BIN"), 3, "txt");

	strcpy(txtName, fileOutName.c_str());
	cout << "txtName:" << txtName << endl;

	/* 写文件，文件不存在创建，若存在则清空原有内容 */
	outFile.open(txtName, ios::out);

	memset(dataValue, 0, sizeof(dataValue));

	ret = get_sufr_hour_tac_value(fileNamePath, dataValue, sizeof(dataValue), &dataLength);
	if (ret != 0)
		printf("error is get_sufr_hour_tac_value \n");

	outFile << dataValue << endl;
	outFile.close();

	//printf("the dataValue is: %s", dataValue);
	return;
}

void GetFilesInDir(char* strPath)
{
	DIR * dir;
	struct dirent * ptr;
	//char file_list[65535][80];

	int i = 0;
	dir = opendir(strPath); //打开一个目录

	while ((ptr = readdir(dir)) != NULL) //循环读取目录数据
	{
		//printf("d_name : %s\n", ptr->d_name); //输出文件名
		string str_File = ptr->d_name;
		file_list.push_back(str_File);
		//strcpy(file_list[i], ptr->d_name); //存储到数组
	}

	closedir(dir);//关闭目录指针
}

void* GetData(void* args)
{
	printf("Function GetData Started..............\n");
	char s_SrcFullPath[512]={0};

	while (true)
	{
		if (file_list.size() > 0)
		{
			printf("Get_Process_surf_hour_data Started.....\n");
			//vector <string>::iterator ele = file_list.begin();
			printf("processing file %s\n",file_list[0].c_str());
			memset(s_SrcFullPath,0,512);
			strcpy(s_SrcFullPath,SRCPATH);
			strcat(s_SrcFullPath,file_list[0].c_str());
			Get_Process_surf_hour_data(s_SrcFullPath, "/test1/");
			std::vector<string>::iterator it = file_list.erase(file_list.begin()); //Delete  element
		}
		else
		{
			printf("files not found!!\n");
		}
		sleep(1);
	}

	return (void*)0;
}

void* MonitorAcidFiles(void* args)
{
	cout<<"MonitorAcidFiles is Started....."<<endl;

	pthread_detach(pthread_self());

	int fd;
	int wd;
	int len;
	int nread;
	char buf[BUFSIZ];
	char cmd[256] = {0};
	struct inotify_event *event;
	fd = inotify_init();
	wd = inotify_add_watch(fd,SRCPATH, IN_MOVED_TO | IN_CREATE);
	if(wd < 0)
	{
		//LOG_ERR("inotify_add_watch failed\n");
		close(fd);
		return NULL;
	}
	while((len = read(fd,buf,sizeof(buf) - 1 )) > 0)
	{
		nread = 0;
		while(len > 0)
		{
			event = (struct inotify_event *)&buf[nread];
			
			if((event->mask & IN_MOVED_TO)|| (event->mask & IN_CREATE))
			{
				//有新的文件写入
				cout<<"New File is Found,"<<event->name<<endl;
				file_list.push_back(event->name);
			}
			nread = nread + sizeof(struct inotify_event) + event->len;
			len = len - sizeof(struct inotify_event) - event->len;
		}
	}

	inotify_rm_watch(fd,wd);

	close(fd);

	return NULL;
}

void InitFileLst()
{
	DIR * dir;
	struct dirent * ptr;
	
	int i=0;
	dir = opendir(SRCPATH); //打开一个目录

	while((ptr = readdir(dir)) != NULL) //循环读取目录数据
	{
		printf("d_name : %s\n", ptr->d_name); //输出文件名
		if(strcmp(ptr->d_name,".")==0||strcmp(ptr->d_name,"..")==0) 
		{ 
			continue; 
		}
		//
		if(strstr(ptr->d_name, "Z_SURF")!=NULL)
		{
			file_list.push_back(ptr->d_name);
		}
	}

	closedir(dir);//关闭目录指针
}

//测试函数，创建4个线程，测试一个文件。
int main(int argc, char *argv[])
{
	/* del by jt 20191016
	int ret = 0;
	char inBufrFName[DFLENGTH] = "a";
	
	if (argc == 1)
	{
		return 0;
	}
	*/

	if (bufr_init("..") < IGNORE)
	{
		printf("bufr_init failed.");
		return -1;
	}
	
	/* del by jt 20191014
	if(argc>=2)
		strcpy(inBufrFName,argv[1]);
	*/
	/* del by jt 20191016
	if (bufr_init("..") < IGNORE)
		return -1;
	*/
	//add by jt 20191014 start
	file_list.clear();
	InitFileLst();

	pthread_t thid1;
	pthread_t thid2;
	//获取目录下的所有文件并添加到文件列表

	if (pthread_create(&thid1, NULL, GetData, NULL) != 0) //创建线程
	{
		printf("thread GetData creation failed\n");
		bufr_end();
		return -1;
	}
	//
	
	if (pthread_create(&thid2, NULL, MonitorAcidFiles, NULL) != 0) //创建线程
	{
		printf("thread MonitorAcidFiles creation failed\n");
		bufr_end();
		return -1;
	}
	
	//add by jt 20191014 end

	//Get_Process_surf_hour_add_min_data(inBufrFName);
	//Get_Process_surf_hour_data(inBufrFName);
	//Get_Process_acidRain_data(inBufrFName);//del by jt 20191014
	//Get_Process_radi_data(inBufrFName);
	//Get_Process_sufr_minute_data(inBufrFName);
	//Get_Process_upar_data(inBufrFName);
	//Get_tac_sufr_hour_data(inBufrFName);
	//add by jt 20191016 start
	/* 令线程pthread先运行 */
	sleep(1);

	/* 线程pthread睡眠2s，此时main可以先执行 */

	/* 等待线程pthread释放 */
	if (pthread_join(thid1, NULL))                  
	{
		printf("thread1 is not exit...\n");
		return -2;
	}
	if (pthread_join(thid2, NULL))                  
	{
		printf("thread2 is not exit...\n");
		return -2;
	}
	//add by jt 20191016 end
	//bufr_end();

	return 0;
}