#include <string>
#include <exception>
#include <cmath>
#include "bufr2zCommon.h"
#include <fstream>
#include <vector>

#ifndef _LINE_OF_BUFR__
#define _LINE_OF_BUFR__

using std::string;
using std::exception;
using namespace std;

#define SUFR_HOR_TAC_TYPE  1
#define CAWN_Z_TYPE        2
#define TORMADO_TAC_TYPE   3
#define CURRENT_AND_PAST_ALL_REPORT      1   /*ww W1 W2都编报*/
#define CURRENT_AND_PAST_NEITHER_REPORT  2   /*ww W1 W2都不编报*/
#define CURRENT_REPORT_BUT_PAST_NO       3   /*ww 编报 W1或W2不编报*/
#define RAIN_FALL_FOR_HOR           1
#define RAIN_FALL_FOR_MINUTE        2
#define SNOW_FALL_FOR_MINUTE        3




const double K2C = -273.2;
const double UPARK2C = -273.15;   /*温度转换，地面和高空不一样--by wy*/


class SomethingWrong : public exception
{
// TODO:

};

class LineOfBufr
{
public:

  struct MyNum
  {
    MyNum(const double val, const double wid):m_value(val), m_width(wid) {}
    const double m_value;
    const double m_width;
  };

  struct MyStr
  {
    MyStr(const char* cval, const int length):m_cval(cval), m_length(length) {}
    const char * m_cval;
    const int m_length;
  };

protected:
  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc) = 0;
 
  
  // factor 为幂的次数（用于换算单位时乘10 除10变换），factor2 为非十倍转换的情形（比如摄氏度与开氏温度）
  // 可以通过查看定义以及详细使用情形进一步理解
  string GetValue(const MyNum& num, const MyStr& str, const int factor = 0, const double factor2 = 0);
  string GetSimilarValue(const MyNum& num, const MyStr& str, const int factor = 0, const double factor2 = 0);
  string GetAmendData(const MyNum& num, const MyStr& str, const int factor=0, const double factor2=0);
  string GetLaLoValue(const string& code, const MyNum& num, const MyStr& str);
  string GetAcidRainLaLoValue(const string& code, const MyNum& num, const MyStr& str);
  string GetWindDirecValueTac(const MyNum& num, const MyStr& str, int typeFlag);  
  string GetWindDirecValue(const MyNum& num, const MyStr& str);
  string GetSunLightNum(const string strValue);
  string GetAcidRainIndicator(const string strValue);
  string GetHundredsAndTens(const string strValue); 
  string GetWindSpeed(const string strValue);
  string GetPilotLarLor(const string strValue, const int flag);
  string GetTimeBase(const string minuteStr, const string secondStr);
  string GetRelativeTime(const string strValue,const string baseValue);
  string GetWorldTime(const string strValue);
  string GetTimeCycle(const string strValue);
  string GetWindHeight(const string strValue, const int flag);
  string GetTemplate(const string strValue);
  string GetVaryingValue(const string strValue, const int flag);
  string GetTempDiff(const string strValue,const string strDewPoint);
  string GetCloudAgeTac(const string strValue);
  string GetCloudAge(const string strValue);

  string GetLastSixHorDrop(const string strValue);
  string GetLast12HorDrop(const string strValue);
  string GetRainFallNum(const string strValue, int flag);
  string GetVV(const string strValue);
  bool   BitTest(const string strValue, const int location);
  int  GetWeatherFlag(const string wwStr,const string w1Str,const string w2Str,const string periodStr,int horTime);
  int    GetTempCompare(const string strValue,const string baseValue);
  string GetCloudHeight(const string strValue);
  int GetStationType(const string strValue);
  int GetHourTime(const string strValue);

  // 存在附加字段（质控码）时，用于替换 line_word[n] += value;
  void AppendWord(const int location, const string& src, const char* qc = NULL);

private:
  const string m_sectionID;
  const unsigned m_countOfWords;   	// 段（行）有几个要素，即下面的指针包含的 string 数目  
  vector <string>  	m_pLine;    	// 段（行）的内容
  int 				m_unitDigit; 	//风向的个位数
 

  // 分别对应台站级质控码、省级质控码、国家级质控码
  string line_words_Q1;
  string line_words_Q2;
  string line_words_Q3;

  void SetQC(string& qc, const int location, const char src);  /*获取指控码，重新组合*/
  
public:
  LineOfBufr(): m_countOfWords(){ }
  // id 为段标识符；count 为段中要素数量
  LineOfBufr(const string& id, const unsigned count);
  ~LineOfBufr();

  int PrintResult(const string= "bufr",const string separator=" ", bool controlFlag=false);
  int printRadiSpecialResult(const string separator=" ");
  
  int PrintSectionQ();
  string GetResult(const string separator=" ", bool controlFlag=false);
  string GetRadiSpecialResult(const string separator=" ", bool controlFlag=false);
  string GetCawnSpecialResult(const string separator = " ", bool controlFlag = false);

  string GetQ1() {return line_words_Q1;}
  string GetQ2() {return line_words_Q2;}
  string GetQ3() {return line_words_Q3;}
};

#endif
