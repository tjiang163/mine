#include "LineOfBufr.h"
#include <map>

// 第一行：区站号、观测时间、纬度、经度、
// 观测场海拔、气压传感器海拔、观测方式、
// 质量控制标识、文件更正标识

#define HIGHT_LEVEL 2 
#define LOW_LEVEL   1
#define HOR_VARY_TEMPLAT 1
#define HOR_VARY_PRESS   2

class LineFirstOfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量


  LineFirstOfBufr(const string& id="", const unsigned count = 26):m_timeOk(false),
  				m_repeatNum(0), m_sensorRepeateNum(0),m_stationType(0),m_stationFlag(0),
  				m_sixHorRainFallFlag(0),m_weatherFlag(0),m_visibilityNum(0),m_vvFlag(0),
  				m_dropFlag(0),m_wwFlag(0),m_hFlag(0),m_Nflag(0),m_ddFlag(0),m_ffFlag(0),
  				m_windDirectionNum(0),m_pressureNum(0),m_cloudTypeNum(0),m_instantSpeedFlag(0),
  				m_tornadoFlag(0),m_cloudFlag(0),m_stationHeight(0),m_hourTime(0),m_dayTime("0"),
  				m_stationID("0"),m_wwValue("0"),m_w1Value("0"),m_w2Value("0"),m_pastTime("0"),LineOfBufr(id, count) { };

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment(const string& filename);
  string  GetHorResult();
  string  GetYYGGTime();


private:
  // 标记观测时间不再统计
  bool m_timeOk;
  int  m_repeatNum;
  int  m_stationType;
  bool m_stationFlag;         /*台站是否找到的标志*/
  int  m_sensorRepeateNum;    /*传感器标识重复的次数*/
  bool m_sixHorRainFallFlag;  /*过去6小时是否有降水的标记*/
  int  m_weatherFlag;         /*天气现象怎样编报的标记*/
  map<int, string> mapCodeName;
  map<int, string> mapValue;
  map<int, string> mapStation;  /*333段层次0中需要编报的测站*/
  int  m_visibilityNum;      /*水平能见度002001出现次数*/
  int  m_vvFlag;              /*12900 水平能见度是否编报的标记*/
  int  m_dropFlag;           /*过去6小时是否编报降水的标记*/
  int  m_wwFlag;			 /*天气现象WW是否编报的标记*/
  int  m_hFlag;			     /*云底高是否编报的标记*/
  int  m_Nflag;			     /*总云量是否编报的标记*/
  int  m_ddFlag;			 /*2分钟风向是否编报的标记*/
  int  m_ffFlag;			 /*2分钟风速是否编报的标记*/
  int  m_windDirectionNum;   /*风向，011001出现次数*/
  int  m_pressureNum;        /*气压，001004出现次数*/
  int  m_cloudTypeNum;          /*云类型，020012出现次数*/
  int  m_instantSpeedFlag;    /*瞬时风速存在的标记*/
  int  m_tornadoFlag;         /*龙卷风存在的标记*/
  int  m_cloudFlag;           /*云是否存在的标记*/  
  int  m_stationHeight;       /*test station height*/
  int  m_hourTime;            /*记录时间的时*/
  string  m_dayTime;
  string  m_stationID; 
  string  m_wwValue;
  string  m_w1Value;
  string  m_w2Value;
  string  m_pastTime;      /*W2 W1对应的过去时间周期*/
};


