#include "LineOfBufr.h"

#define THE_FIRST_PH_OR_K  					1
#define THE_SECOND_PH_OR_K  				2
#define THE_THIRD_PH_OR_K  					3
#define THE_AVERAGE_PH_OR_K  				4
#define THE_REPEAT_FIRST_PH_OR_K  			5
#define THE_REPEAT_SECOND_PH_OR_K  			6
#define THE_REPEAT_THIRD_PH_OR_K  			7
#define THE_REPEAT_AVERAGE_PH_OR_K  		8


class Line2OfAcidRain: public LineOfBufr
{

public:
  // id 为段标识符；count 为段中要素数量


  Line2OfAcidRain(const string& id="", const unsigned count = 28):m_PhNum(1),m_kNum(1),m_dropFlag(0),weatherTest(""), LineOfBufr(id, count) { };

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  bool  GetDropFlag();
  
private:
	int  m_flag;     // 标记一阶统计
	int  m_timeNum;  //标记日期观测次数
	bool m_timeOk;   // 标记观测时间,0:初次观测，1:复次观测
	bool m_tempOk;   // 标记温度时间,0:初次温度，1:复次温度
	bool m_dropFlag;  //降水量存在标志。如果不存在后面数据不用编报。
	int  m_PhNum;    // 标记第几次PH的值
	int  m_kNum;    //标记初次还是复次观测K
	int  m_DirecNum; //标记风向的次数
	int  m_speedNum; //标记风速的次数
	string  weatherTest;
};
