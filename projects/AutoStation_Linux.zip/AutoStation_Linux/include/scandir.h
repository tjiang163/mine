#ifndef __SCANDIR__
#define  __SCANDIR__

#include "common.h"

#define IS_EXIST 0
#define WRITE_ACCESS 2
#define READ_ACCESS 4
#define READ_WRITE_ACCESS 6

typedef struct dir_entry{
	char name[MAX_FILE_NAME_LEN];
	int size;
	int attrib;
}DirEntry;

typedef struct file_item{
   char filename[MAX_FILE_NAME_LEN];
   int fileSize;
   unsigned char *fileData;
}FileItem;

void *find_first(const char *inDirName,DirEntry *ent);
int find_next(void *dirid,DirEntry *ent);
int close_dir(void *dirid);
int file_exist(const char *fileName);
int load_source_file(const char fname[],FileItem *fileItem);
#endif