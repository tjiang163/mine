
#include "LineOfBufr.h"
#include "Reaper.h"

// 5 风观测数据
class Line5OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line5OfBufr(const string& id = "WI", const unsigned count = 16): m_maxW("011042"),m_extW("011046"),m_0M2M10M (0), m_1H6H12H(0) , LineOfBufr(id, count)
  {
  }
  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  Reaper m_maxW;  // 获取#最大风X出现时间#的时机
  Reaper m_extW;  // 获取#极大风X出现时间#的时机
  // 区分瞬时风X、2分钟平均风X、10分钟平均风X
  int m_0M2M10M;
  // 区分小时极大风X、6小时极大风X、12小时极大风X
  int m_1H6H12H;
};
