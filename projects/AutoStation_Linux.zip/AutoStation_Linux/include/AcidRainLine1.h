#include "LineOfBufr.h"


class Line1OfAcidRain: public LineOfBufr
{

public:
  // id 为段标识符；count 为段中要素数量


  Line1OfAcidRain(const string& id="", const unsigned count = 5):m_timeOk(false), LineOfBufr(id, count) { };

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  
  
private:
	// 标记观测时间不再统计
	bool m_timeOk;

};
