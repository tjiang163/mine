#include "LineOfBufr.h"




class Line1OfRadi: public LineOfBufr
{

public:
  // id 为段标识符；count 为段中要素数量


  Line1OfRadi(const string& id="", const unsigned count = 4):m_timeOk(false), LineOfBufr(id, count) 
  {
  }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment(const string& filename);
  
  
private:
	// 标记观测时间不再统计
	bool m_timeOk;

};
