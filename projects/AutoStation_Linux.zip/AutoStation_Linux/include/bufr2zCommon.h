#include <sstream>
#include <string>
#include <iomanip>
#include <iostream>


using std::string;
using std::ostringstream;
using namespace std;

#ifndef __COMMON_H__
#define __COMMON_H__

// 格式化输出
inline string FormatOut(const string& input, const unsigned len, const char fill = '0')
{
  ostringstream oss;
  
  if (input == "/")
    oss << std::right << std::setfill('/') << std::setw(len) << input;
  else if(input.at(0) == '-')
    oss << "-" << std::right << std::setfill(fill) << std::setw(len-1) << input.substr(1);
  else
    oss << std::right << std::setfill(fill) << std::setw(len) << input;
  
  return oss.str();
}

//格式化输出，左对齐，与FormatOut的正好相反
inline string FormatOutLeft(const string& input, const unsigned len, const char fill = '0')
{
  ostringstream oss;
  
  if (input == "/")
    oss << std::left << std::setfill('/') << std::setw(len) << input;
  else if(input.at(0) == '-')
    oss << "-" << std::left << std::setfill(fill) << std::setw(len-1) << input.substr(1);
  else
    oss << std::left << std::setw(len) <<  std::setfill('0') << input;
  
  return oss.str();
}

//对于长度大于3位的string，将其截短，只要低3位
inline string FormatOut3Len(const string& input)
{
	string  strValue = "abc";	
	int 	j=2;
	char 	pTest[3];

	
	int lenTest = input.length();

	if (lenTest > 3)
	{
		for (int i =(lenTest-1); i>(lenTest-4); i--)
		{																				
			pTest[j] = input.c_str()[i];											
			j--;			
		}
		
		//char 转换成string
		strValue.assign(pTest,3);
	}
	else
		strValue = input;		

	return strValue;
}

//对于长度大于3位的string，将其截短，只要低3位,扩展一下，要低4位。
inline string FormatOutLeftLen(const string& input, int bitNum)
{
	string  strValue = "abc";	
	int 	j=bitNum-1;
	char 	pTest[8];    /*先定义一个8，因为string长度没有超过8的*/

	
	int lenTest = input.length();

	if (lenTest > bitNum)
	{
		for (int i =(lenTest-1); i>= (lenTest-bitNum); i--)
		{																				
			pTest[j] = input.c_str()[i];											
			j--;			
		}
		
		//char 转换成string
		strValue.assign(pTest,bitNum);
	}
	else
		strValue = input;		

	return strValue;
}


#endif
