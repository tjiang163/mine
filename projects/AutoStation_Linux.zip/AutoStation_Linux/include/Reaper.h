#include <string>
#include "bufr2zCommon.h"


#ifndef _REAPER_H__
#define _REAPER_H__

using std::string;

// 获取#出现时间#的时机
class Reaper
{
public:
  // 用于判断获取#XXX出现时间#要素的时机
  class Occasion
  {
  private:  
    // 前置条件是否满足，过滤掉不符合的时间要素
    bool m_isReady;
    // 填充完毕，过滤掉后续的时间要素
    bool m_isDone;
  
  public:
    Occasion(): m_isReady(false), m_isDone(false) {}
    bool able() { return m_isReady && !m_isDone; } 
    void Prepare() { m_isReady = true; }
    void Done() { m_isDone = true; }
  };

private:
  string m_code;
  Occasion m_occasion;
  string m_hm;

public:
  Reaper(const string& code): m_code(code) {}
  bool Filter(const string& code, const string& strVal, bool moreCondition = true);
  string GetHM() { return m_hm;}
  void setHM() {m_hm = ""; }
};

#endif
