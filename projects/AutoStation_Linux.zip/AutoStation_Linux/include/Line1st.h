#include "LineOfBufr.h"

// 第一行：区站号、观测时间、纬度、经度、
// 观测场海拔、气压传感器海拔、观测方式、
// 质量控制标识、文件更正标识
class Line1OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量


  Line1OfBufr(const string& id="", const unsigned count = 9):m_timeOk(false),m_repeatNum(0), LineOfBufr(id, count) { };

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment(const string& filename);

private:
  // 标记观测时间不再统计
  bool m_timeOk;
  int  m_repeatNum;
};

