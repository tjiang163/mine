

#include "LineOfBufr.h"

// 11.人工观测连续天气现象
class Line11OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line11OfBufr(const string& id = "MW", const unsigned count = 1): LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
};
