
#include "LineOfBufr.h"
#include "Reaper.h"

// 8 人工观测能见度、云、天数据
class Line8OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line8OfBufr(const string& id = "CW", const unsigned count = 12 ): m_flag(0),m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment();

private:
  int m_flag;
  int m_repeatNum;      //云类型code出现的次数
  // 8.8 过去天气描述时间周期
  Reaper::Occasion m_occa;
};
