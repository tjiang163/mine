
#include "LineOfBufr.h"
#include <cmath>



// 10.小时内每分钟降水量数据.此用于分钟降水。因为没有半角空格分隔，count为1，
class Line10OfBufr: public LineOfBufr
{
	
public:

  // id 为段标识符；count 为段中要素数量
  Line10OfBufr(const string& id = "MR", const unsigned count = 1): LineOfBufr(id, count) { }
  
  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

 
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment();
  
};

//10.小时内每分钟降水量数据.此类专用于小时降水。因为质控码需要60个，count为60，
class Line10OfBufrForHour: public LineOfBufr
{	
public:

  // id 为段标识符；count 为段中要素数量
  Line10OfBufrForHour(const string& id = "MR", const unsigned count = 60): LineOfBufr(id, count) { }
  
  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
 
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment();

  
};

