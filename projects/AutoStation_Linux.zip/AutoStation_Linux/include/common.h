#ifndef __COMMON__
#define __COMMON__

/*****************************/
/*type define */
#define uchar unsigned char 
/*****************************/

#define MAX_FILE_NAME_LEN 256
#define MAX_LINE_LENGTH 512
#define LINE_THRESHOLD 5

#define BYTE_BITS_NUM 8

#define OK 0
#define ER -1

#define TRUE 1
#define FALSE 0

#endif