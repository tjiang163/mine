#include "LineOfBufr.h"

// 分钟数据
class Line1OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line1OfSufrMinute(const string& id = "", const unsigned count = 9): m_flag(0),m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_flag;    //60个文件都有测站基本信息。只记录一次
  int m_repeatNum;   
};

class Line2OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line2OfSufrMinute(const string& id = "PP", const unsigned count = 8): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 日照的个数
 
};




class Line3OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line3OfSufrMinute(const string& id = "TH", const unsigned count = 13): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
 
};



class Line4OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line4OfSufrMinute(const string& id = "RE", const unsigned count = 8): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
 
};




class Line5OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line5OfSufrMinute(const string& id = "WI", const unsigned count = 16): m_repeatNum(0),m_timeCycle(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  
  // 区分瞬时风X、2分钟平均风X、10分钟平均风X
  int m_timeCycle;  
 
};



class Line6OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line6OfSufrMinute(const string& id = "DT", const unsigned count = 19): m_repeatNum(0),m_tempFlag(0),m_groudTemp(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_tempFlag; 
  int m_groudTemp;
 
};

class Line7OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line7OfSufrMinute(const string& id = "VV", const unsigned count = 4): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line8OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line8OfSufrMinute(const string& id = "CW", const unsigned count = 12): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag;
};

class Line9OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line9OfSufrMinute(const string& id = "SP", const unsigned count = 10): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

/*分钟降水量 60分钟都记录 记录当前时刻的分钟降水量 其它时刻记成缺测*/
class Line10OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line10OfSufrMinute(const string& id = "MR", const unsigned count = 1): m_repeatNum(0),m_flag(0),m_minuteValue(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
  int m_minuteValue;
};

/*人工观测连续天气现象 缺测 因为没有人工观测了*/
class Line11OfSufrMinute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line11OfSufrMinute(const string& id = "MW", const unsigned count = 1): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};


class Line2OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line2OfSufr60Minute(const string& id = "PP", const unsigned count = 60): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 日照的个数
 
};

class Line3OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line3OfSufr60Minute(const string& id = "TT", const unsigned count = 60): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
 
};

class Line4OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line4OfSufr60Minute(const string& id = "RH", const unsigned count = 60): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
 
};

class Line5OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line5OfSufr60Minute(const string& id = "WI", const unsigned count = 60): m_repeatNum(0),m_timeCycle(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_timeCycle;
 
};

class Line6OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line6OfSufr60Minute(const string& id = "RR", const unsigned count = 60): m_repeatNum(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
 
};

class Line7OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line7OfSufr60Minute(const string& id = "GT", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line8OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line8OfSufr60Minute(const string& id = "DT", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag;
};

class Line9OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line9OfSufr60Minute(const string& id = "D1", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line10OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line10OfSufr60Minute(const string& id = "D2", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line11OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line11OfSufr60Minute(const string& id = "D3", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line12OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line12OfSufr60Minute(const string& id = "D4", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};

class Line13OfSufr60Minute: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line13OfSufr60Minute(const string& id = "D5", const unsigned count = 60): m_repeatNum(0),m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_repeatNum;  // 个数
  int m_flag; 
};


