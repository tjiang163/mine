
#include "LineOfBufr.h"
#include "Reaper.h"

// 3 温度和湿度数据
class Line3OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line3OfBufr(const string& id = "TH", const unsigned count = 13):m_maxT("012011"),m_minT("012012"), m_minH("013007"), LineOfBufr(id, count)
  {
  }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  Reaper m_maxT;  // 获取#最高气温出现时间#的时机
  Reaper m_minT;  // 获取#最低气温出现时间#的时机
  Reaper m_minH;  // 获取#最小相对湿度出现时间#的时机
};
