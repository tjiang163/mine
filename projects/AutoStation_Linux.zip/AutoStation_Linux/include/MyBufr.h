#include "Line1st.h"
#include "Line2nd.h"
#include "Line3rd.h"
#include "Line4th.h"
#include "Line5th.h"
#include "Line6th.h"
#include "Line7th.h"
#include "Line8th.h"
#include "Line9th.h"
#include "Line10th.h"
#include "Line11th.h"
#include <exception>
#include "bufr.h"
#include <math.h>
#include "RadiLine1.h"
#include "RadiLine2.h"
#include "AcidRainLine1.h"
#include "AcidRainLine2.h"
#include "SunLight.h"
#include "UparLine.h"
#include "SufrMinute.h"
#include "lineProcess1.h"


#define  STATION_BASIC_INFO   			0 
#define  PRESSURE_INFO        			1	 
#define BUFR_TO_INT3_BE(p) ((((int)(*(p)))<<16) + (((int)(*(p+1)))<<8) + (*(p+2))) 
#define HEAD_LEN  8


class SomethingUnexpected: public exception
{
// TODO: 超出当前业务的处理范围

};

//using LineOfBufr::MyNum;
//using LineOfBufr::MyStr;
typedef LineOfBufr::MyNum MyNum;
typedef LineOfBufr::MyStr MyStr;

class MyBufr
{
private:
  //0  测站基本信息
  
  //1  气压  002201
  //2  温度和湿度
  //3  降水 4
  //4  蒸发 4
  //5  风
  
  //6  地表温度、浅层地温和深层地温 6
  //7  草面和雪面温度 6
  //8  路面温度 x
  //9  能见度数据 7 8
  //10 云数据 8 
  
  //11 地面状态 8 
  //12 积雪深度、雪压 9
  //13 冻土深度 9
  //14 电线积冰 x
  //15 路面状况 x
  
  //16 其他 8 9 11
  //17 日照 x
  unsigned m_sectionsNum;
  string m_preCode;
  Line1OfBufr m_line1;
  Line2OfBufr m_line2;
  Line3OfBufr m_line3;
  Line4OfBufr m_line4;
  Line5OfBufr m_line5;

  Line6OfBufr m_line6;
  Line7OfBufr m_line7;
  Line8OfBufr m_line8;
  Line9OfBufr m_line9;

  Line10OfBufr m_line10;
  Line10OfBufrForHour  m_line10ForHour;   //此转为小时编报时分钟的函数
  Line11OfBufr m_line11;  

  Line1OfSufrMinute m_sufrMinuteL1;
  Line2OfSufrMinute m_sufrMinuteL2;
  Line3OfSufrMinute m_sufrMinuteL3;
  Line4OfSufrMinute m_sufrMinuteL4;
  Line5OfSufrMinute m_sufrMinuteL5;
  Line6OfSufrMinute m_sufrMinuteL6;
  Line7OfSufrMinute m_sufrMinuteL7;
  Line8OfSufrMinute m_sufrMinuteL8;
  Line9OfSufrMinute m_sufrMinuteL9;
  Line10OfSufrMinute m_sufrMinuteL10;
  Line11OfSufrMinute m_sufrMinuteL11;
  

  Line2OfSufr60Minute  m_sufr60MinuteL2;
  Line3OfSufr60Minute  m_sufr60MinuteL3;
  Line4OfSufr60Minute  m_sufr60MinuteL4;
  Line5OfSufr60Minute  m_sufr60MinuteL5;
  Line6OfSufr60Minute  m_sufr60MinuteL6;
  Line7OfSufr60Minute  m_sufr60MinuteL7;
  Line8OfSufr60Minute  m_sufr60MinuteL8;
  Line9OfSufr60Minute  m_sufr60MinuteL9;
  Line10OfSufr60Minute m_sufr60MinuteL10;
  Line11OfSufr60Minute m_sufr60MinuteL11;
  Line12OfSufr60Minute m_sufr60MinuteL12;
  Line13OfSufr60Minute m_sufr60MinuteL13;
  
  Line1OfRadi  m_radiLine1;
  Line2OfRadi  m_radiLine2;	

  Line1OfAcidRain m_acidRainLine1;
  Line2OfAcidRain m_acidRainLine2;
 
  Line1OfSunLight m_sunLightLine1;
  Line2OfSunLight m_sunLightLine2;
  LineAOfUpar     m_uparLineA;
  LineBOfUpar     m_uparLineB;
  LineCOfUpar     m_uparLineC;
  LineDOfUpar     m_uparLineD;
  LineAOfPilot	  m_pilotLineA;
  //LineBOfPilot	  m_pilotLineB;
 // LineCOfPilot	  m_pilotLineC;
 // LineDOfPilot	  m_pilotLineD;
  
  LineFirstOfBufr m_lineFirst;

  

public:
  MyBufr():m_sectionsNum(0), m_preCode("") { }

  int FillSufrHour(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);  
  int FillSufrMinute(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillSufrMinute60Files(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillRadi(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillAcidRain(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  //int FillRegRainFall(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillRainFallHour(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillSunLight(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillUpar(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillPilot(const double *value,const int n,const char *cval,const int cvallen, const DescriptorItem *pdes, const int si, const void *pother);
  int FillSufrHourTac(const double *value,const int n,const char *cval,const int cvallen, 
  						const DescriptorItem *pdes, const int si, const void *pother);  

  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachments(const string& filename);
  void DebugSectionOne();
  void DebugRainFallHour();
  void DebugSufrMinute();
  void DebugRadi();
  void DebugAcidRain();
  void DebugSunLight();
  string GetSurfHourMinResult();
  string GetSurfHourSimpleResult();
  string GetSurfMinuteResult();           /*1个分钟BIN文件生成一个txt文本*/
  string GetSurf60MinuteResult();         /*60个分钟BIN文件生成一个txt文本*/
  string GetRainFallHourResult();
  string GetRainFallMinuteResult();
  string GetRainFallMinuteInHorResult();
  string GetRadiResult();
  string GetAcidRainResult();
  string GetSunLightResult();
  string GetUparResultSecA(); 
  string GetUparResultSecB(); 
  string GetUparResultSecC(); 
  string GetUparResultSecD(); 
  string GetPilotResult();
  string GetSufrHourTacResult();
  string GetSufrHorTacTime();
};


