
#include "LineOfBufr.h"
#include "Reaper.h"

// 6 地温数据
class Line6OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line6OfBufr(const string& id = "DT", const unsigned count = 19):m_flag (0), m_count(0), m_switch(0),
	m_dmaxT("012061"), m_dminT("012061"),
  	m_cmaxT("012061"), m_cminT("012061"),
        LineOfBufr(id, count)
  {
  }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_flag;
  // 5cm，10cm，15cm，20cm，40cm 等
  unsigned m_count;
  unsigned m_switch; // 地表 or 草面

  Reaper m_dmaxT;  // 获取#出现时间#的时机
  Reaper m_dminT;  // 获取#出现时间#的时机
  Reaper m_cmaxT;  // 获取#出现时间#的时机
  Reaper m_cminT;  // 获取#出现时间#的时机
};
