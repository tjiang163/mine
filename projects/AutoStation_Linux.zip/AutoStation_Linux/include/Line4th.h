#include "LineOfBufr.h"

// 4 累计降水和蒸发量数据
class Line4OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line4OfBufr(const string& id = "RE", const unsigned count = 8): LineOfBufr(id, count),m_isDone(false) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_flag;  // used by 4.8
  bool m_isDone;  // used by 4.6 
};
