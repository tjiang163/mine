
#include "LineOfBufr.h"
#include "Reaper.h"

// 7 自动观测能见度数据
class Line7OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line7OfBufr(const string& id = "VV", const unsigned count = 4):m_flag(0), m_minT("020001"), LineOfBufr(id, count) 
  {
  }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_flag;
  Reaper m_minT;  // 获取#出现时间#的时机
};
