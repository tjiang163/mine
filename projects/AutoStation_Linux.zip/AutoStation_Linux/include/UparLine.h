
#include "LineOfBufr.h"
#include "string.h"

class LineAOfUpar: public LineOfBufr
{

public:
	
  // id 为段标识符；count 为段中要素测量组的数量
  LineAOfUpar(const string& id="", const unsigned count = 28): m_timeNum(0),m_repeatNum(0),m_lapsNum(0),m_lapsElements(0),m_standFlag(0),
  				m_maxWindNum(0), m_maxWindFlag(0),m_hourBase("0"),m_minuteBase("0"),m_secondBase("0"),m_timeBase("0"),
  				m_radiosonde(""),m_temperature(""),m_pressValue(""),m_lowPointTemp(""),m_windDirection(""),m_windSpeed(""),
  				m_lar(""),m_lor(""),m_larUnit(""),
 				 m_pressOfMaxWind1(""),m_direcOfMaxWind1(""),m_speedOfMaxWind1(""),m_speedOriginal1(""),m_larMaxWind1(""),m_larUnitMaxWind1(""),
 				 m_lorMaxWind1(""),m_relativeMaxWind1(""),m_pressOfMaxWind2(""),m_direcOfMaxWind2(""),m_speedOfMaxWind2(""),m_speedOriginal2(""),
 				 m_larMaxWind2(""),m_larUnitMaxWind2(""),m_lorMaxWind2(""),m_relativeMaxWind2(""),m_relativeTime(""),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  
private:
	// 标记观测时间不再统计
	int m_timeNum;
	int m_repeatNum;
	int m_lapsNum;
	int m_lapsElements;
	int m_standFlag;           //100000pa气压存在与否的标志
	int m_maxWindNum;
	int m_maxWindFlag;
	string m_hourBase;
	string m_minuteBase;
	string m_secondBase;
	string m_timeBase;         //时间基值
	string m_radiosonde;       //雷送及探测仪系统，先记录，后编报
	string m_temperature;      //地面层温度
	string m_pressValue;       //地面层气压
	string m_lowPointTemp;     //地面层露点温度
	string m_windDirection;    //地面层风向
	string m_windSpeed;        //地面层风速
	string m_lar;
	string m_lor;
	string m_larUnit;
	string m_pressOfMaxWind1;   //最大风层的气压1
	string m_direcOfMaxWind1;   //最大风层的风向1
	string m_speedOfMaxWind1;   //最大风层的风速1，用于编报
	string m_speedOriginal1;    //最大风层的风速原始值，用于比较数组
	string m_larMaxWind1;       //最大风层的纬度前3位1
	string m_larUnitMaxWind1;   //最大风层的纬度个位1
	string m_lorMaxWind1;       //最大风层的经度1
	string m_relativeMaxWind1;  //最大风层的相对时间差1
	string m_pressOfMaxWind2;   //最大风层的气压2
	string m_direcOfMaxWind2;   //最大风层的风向2
	string m_speedOfMaxWind2;   //最大风层的风速2
	string m_speedOriginal2;    //最大风层的风速原始值，用于比较数组
	string m_larMaxWind2;       //最大风层的纬度前3位2
	string m_larUnitMaxWind2;   //最大风层的纬度个位2
	string m_lorMaxWind2;       //最大风层的经度2
	string m_relativeMaxWind2;  //最大风层的相对时间差2
	string m_relativeTime;     //62626段的相对时间差
};


class LineCOfUpar: public LineOfBufr
{

public:
	
  // id 为段标识符；count 为段中要素测量组的数量
  LineCOfUpar(const string& id="", const unsigned count = 15): m_timeNum(0),m_repeatNum(0),m_lapsNum(0),m_lapsElements(0),
  				m_Flag1(0),m_Flag2(0),m_Flag3(0),m_Flag4(0),m_Flag5(0),m_Flag6(0),m_Flag7(0),
  				m_Flag8(0),m_Flag9(0),m_Flag10(0),m_indicateFlag(0),m_indicateSign("0"),m_standFlag(0),
  				m_maxWindNum(0), m_maxWindFlag(0),m_hourBase("0"),m_minuteBase("0"),m_secondBase("0"),m_timeBase("0"),
  				m_radiosonde(""),m_temperature(""),m_pressValue(""),m_lowPointTemp(""),m_windDirection(""),m_windSpeed(""),
  				m_lar(""),m_lor(""),m_larUnit(""),
 				 m_pressOfMaxWind1(""),m_direcOfMaxWind1(""),m_speedOfMaxWind1(""),m_speedOriginal1(""),m_larMaxWind1(""),m_larUnitMaxWind1(""),
 				 m_lorMaxWind1(""),m_relativeMaxWind1(""),m_pressOfMaxWind2(""),m_direcOfMaxWind2(""),m_speedOfMaxWind2(""),m_speedOriginal2(""),
 				 m_larMaxWind2(""),m_larUnitMaxWind2(""),m_lorMaxWind2(""),m_relativeMaxWind2(""),m_relativeTime(""),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  
private:
	// 标记观测时间不再统计
	int m_timeNum;
	int m_repeatNum;
	int m_lapsNum;
	int m_lapsElements;
	int m_Flag1;           //7000pa气压存在与否的标志
	int m_Flag2;           //5000pa气压存在与否的标志
	int m_Flag3;           //3000pa气压存在与否的标志
	int m_Flag4;           //2000pa气压存在与否的标志
	int m_Flag5;           //1000pa气压存在与否的标志
	int m_Flag6;           //700pa气压存在与否的标志
	int m_Flag7;           //500pa气压存在与否的标志
	int m_Flag8;           //300pa气压存在与否的标志
	int m_Flag9;           //200pa气压存在与否的标志
	int m_Flag10;           //100pa气压存在与否的标志
	int m_indicateFlag;           //气压的十位数值
	string m_indicateSign;
	int m_standFlag;
	int m_maxWindNum;
	int m_maxWindFlag;
	string m_hourBase;
	string m_minuteBase;
	string m_secondBase;
	string m_timeBase;         //时间基值
	string m_radiosonde;       //雷送及探测仪系统，先记录，后编报
	string m_temperature;      //地面层温度
	string m_pressValue;       //地面层气压
	string m_lowPointTemp;     //地面层露点温度
	string m_windDirection;    //地面层风向
	string m_windSpeed;        //地面层风速
	string m_lar;
	string m_lor;
	string m_larUnit;
	string m_pressOfMaxWind1;   //最大风层的气压1
	string m_direcOfMaxWind1;   //最大风层的风向1
	string m_speedOfMaxWind1;   //最大风层的风速1，用于编报
	string m_speedOriginal1;    //最大风层的风速原始值，用于比较数组
	string m_larMaxWind1;       //最大风层的纬度前3位1
	string m_larUnitMaxWind1;   //最大风层的纬度个位1
	string m_lorMaxWind1;       //最大风层的经度1
	string m_relativeMaxWind1;  //最大风层的相对时间差1
	string m_pressOfMaxWind2;   //最大风层的气压2
	string m_direcOfMaxWind2;   //最大风层的风向2
	string m_speedOfMaxWind2;   //最大风层的风速2
	string m_speedOriginal2;    //最大风层的风速原始值，用于比较数组
	string m_larMaxWind2;       //最大风层的纬度前3位2
	string m_larUnitMaxWind2;   //最大风层的纬度个位2
	string m_lorMaxWind2;       //最大风层的经度2
	string m_relativeMaxWind2;  //最大风层的相对时间差2
	string m_relativeTime;     //62626段的相对时间差
};

class LineBOfUpar: public LineOfBufr
{

public:
	
  // id 为段标识符；count 为段中要素测量组的数量
  LineBOfUpar(const string& id="", const unsigned count = 78): m_timeNum(0),m_repeatNum(0),m_airPressNum(0),
  					m_lapsNum(0),m_cloudType(0),m_cloudNum(0),m_pressFlag(0),m_minuteBase("0"),m_secondBase("0"),m_timeBase("0"),
  					m_temperature(""),m_relativeTime(""),m_cloudHeight(""),m_radiosonde("0"),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc); 
  
private:
	// 标记观测时间不再统计
	int  m_timeNum;
	int  m_repeatNum;
	int  m_airPressNum;
	int  m_lapsNum;
	int  m_cloudType;
	int  m_cloudNum;
	int  m_pressFlag;
	string m_minuteBase;
	string m_secondBase;
	string m_timeBase;
	string  deviceData;	
	string m_temperature;
	string m_relativeTime;	   //65656段的相对时间差
	string m_cloudHeight;
	string m_radiosonde;       //雷送及探测仪系统，先记录，后编报
};

class LineDOfUpar: public LineOfBufr
{

public:
	
  // id 为段标识符；count 为段中要素测量组的数量
  LineDOfUpar(const string& id="", const unsigned count = 15): m_timeNum(0),m_repeatNum(0),m_airPressNum(0),
  					m_lapsNum(0),m_cloudType(0),m_cloudNum(0),m_pressFlag(0),m_minuteBase("0"),m_secondBase("0"),m_timeBase("0"),
  					m_temperature(""),m_relativeTime(""),m_cloudHeight(""),m_radiosonde("0"),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc); 
  
private:
	// 标记观测时间不再统计
	int  m_timeNum;
	int  m_repeatNum;
	int  m_airPressNum;
	int  m_lapsNum;
	int  m_cloudType;
	int  m_cloudNum;
	int  m_pressFlag;
	string m_minuteBase;
	string m_secondBase;
	string m_timeBase;
	string  deviceData;	
	string m_temperature;
	string m_relativeTime;	   //65656段的相对时间差
	string m_cloudHeight;
	string m_radiosonde;       //雷送及探测仪系统，先记录，后编报
};

class LineAOfPilot: public LineOfBufr
{

public:
	
	// id 为段标识符；count 为段中要素测量组的数量
	LineAOfPilot(const string& id="", const unsigned count = 43): m_timeNum(0),m_repeatNum(0),m_speedNum(0),
					m_minuteBase("0"),m_secondBase("0"),m_timeBase("0"),m_deviceData(""),m_unitDigit(0),m_geopotenValue(""),
					m_windDirection(""),m_pressureNum(0),m_maxWindFlag(0),LineOfBufr(id, count) { }

	virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
	

private:
		
	int   	m_timeNum;     //标记放球时间
	int     m_repeatNum;   //标记气压重复次数
	int     m_speedNum;    //风速code出现的次数
	string  m_minuteBase;
	string  m_secondBase;
	string  m_timeBase;
	string 	m_deviceData;    //设备类型
	int     m_unitDigit;    //风向的个位数
	string  m_geopotenValueTest; //位势高度临时记录
	string  m_windDirectionTest; //临时记录风向
	string  m_speedValue;
	string  m_geopotenValue; //位势高度
	string  m_windDirection; //风向
	int 	m_pressureNum;
	int     m_maxWindFlag;  //最大风出现标志。1：有最大风。0：没有最大风	

};


#if 0


class LineBOfPilot: public LineOfBufr
{

public:
	
	// id 为段标识符；count 为段中要素测量组的数量
	LineBOfPilot(const string& id="", const unsigned count = 41): m_timeNum(0),m_repeatNum(0),m_airPressureNum(0),
					m_deviceData(""),m_timeBase("0"),LineOfBufr(id, count) { }

	virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
	

private:
		
	int   	m_timeNum;     		//标记放球时间	
	int     m_repeatNum;   		//标记风的高度重复次数
	int		m_airPressureNum;	//
	string 	m_deviceData;    	//设备类型
	string  m_timeBase;
};

class LineCOfPilot: public LineOfBufr
{

public:
	
	// id 为段标识符；count 为段中要素测量组的数量
	LineCOfPilot(const string& id="", const unsigned count = 31): m_timeNum(0),m_repeatNum(0),
					m_speedNum(0),m_timeBase("0"),m_deviceData(""),m_unitDigit(0),m_geopotenValue(""),
					m_windDirection(""),m_pressureNum(0),m_maxWindFlag(0),LineOfBufr(id, count) { }

	virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
		
	int   	m_timeNum;     //标记放球时间
	int     m_repeatNum;   //标记气压重复次数
	int     m_speedNum;    //风速code出现的次数
	string  m_timeBase;
	string 	m_deviceData;    //设备类型
	int     m_unitDigit;    //风向的个位数
	string  m_geopotenValueTest; //位势高度临时记录
	string  m_windDirectionTest; //临时记录风向
	string  m_speedValue;
	string  m_geopotenValue; //位势高度
	string  m_windDirection; //风向
	int 	m_pressureNum;
	int     m_maxWindFlag;  //最大风出现标志。1：有最大风。0：没有最大风
};

class LineDOfPilot: public LineOfBufr
{

public:
	
	// id 为段标识符；count 为段中要素测量组的数量
	LineDOfPilot(const string& id="", const unsigned count = 41): m_timeNum(0),m_repeatNum(0),m_airPressureNum(0),
						m_deviceData(""),m_timeBase("0"),LineOfBufr(id, count) { }

	virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
	

private:
		
	int   	m_timeNum;     		//标记放球时间	
	int     m_repeatNum;   		//标记风的高度重复次数
	int		m_airPressureNum;	//
	string 	m_deviceData;    	//设备类型
	string  m_timeBase;
};
#endif

