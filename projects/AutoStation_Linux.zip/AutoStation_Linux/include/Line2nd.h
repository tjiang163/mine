
#include "LineOfBufr.h"
#include "Reaper.h"

// 2 气压数据
class Line2OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line2OfBufr(const string& id = "PP", const unsigned count = 8):m_flag(0), m_maxT("010004"), m_minT("010004"), LineOfBufr(id, count)
  {
  }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  // 区分气压、最高气压、最低气压
  int m_flag;
  Reaper m_maxT;  // 获取#出现时间#的时机
  Reaper m_minT;  // 获取#出现时间#的时机
};
