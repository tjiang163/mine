#include "LineOfBufr.h"

// 4 累计降水和蒸发量数据
class Line1OfSunLight: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line1OfSunLight(const string& id = "", const unsigned count = 4): m_flag(0),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_flag;  
 
};

class Line2OfSunLight: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line2OfSunLight(const string& id = "", const unsigned count = 26): m_sunLightNum(1),LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);

private:
  int m_sunLightNum;  // 日照的个数
 
};

