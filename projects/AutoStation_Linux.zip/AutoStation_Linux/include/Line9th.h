
#include "LineOfBufr.h"

// 9 其它重要天气数据
class Line9OfBufr: public LineOfBufr
{
public:
  // id 为段标识符；count 为段中要素数量
  Line9OfBufr(const string& id = "SP", const unsigned count = 10): LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
};
