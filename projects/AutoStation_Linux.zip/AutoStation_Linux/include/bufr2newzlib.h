#ifndef BUFR2NEWZLIB_H
#define BUFR2NEWZLIB_H
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <iostream>
using namespace std;

// 【国内观测数据酸雨编码格式】
int get_acidRain_value(char *pFilePath, char* pGetedData, int iMaxLen, int* pDataLen);
// 【国内观测数据RADI编码格式】
int get_radi_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
// 【国内小时观测数据编码格式】
int get_sufr_hour_add_min_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
int get_surf_hour_simple_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);

//BUFR--TAC
int get_sufr_hour_tac_value(char *pFilePath, char* pGetedData, int iMaxLen, int* pDataLen);

//【国内地面分钟观测数据BUFR编码格式】
int get_sufr_minute_value(char *pFilePath, char* pGetedData, int iMaxLen, int* pDataLen);
int get_sufr_minute_value_60_files(char *pFilePath, char* pGetedData, int iMaxLen, int* pDataLen);

int get_rainFall_minute_value(char *pFilePath, char* pGetedData, int iMaxLen, int* pDataLen);

//【国内日照小时观测数据BUFR编码格式】
int get_sunLight_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
//【国内高空综合观测数据BUFR编码格式】
int get_upar_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
//【国内高空探风观测数据BUFR编码格式】
int get_pilot_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
//【国内降水数据BUFR编码格式】
int get_rainFall_hour_value(char *pFilePath, char* pGetedData,int iMaxLen ,int* pDataLen);
int min_file_proc( string minFilePath, void * pMyBufr);

class bufr2newzlib
{
public:
    bufr2newzlib();
};

#endif // BUFR2NEWZLIB_H
