
#include "LineOfBufr.h"
#include "Reaper.h"

#define GLO_RADI_MAX_TIME_TYPE 1   // 总辐射辐照度最大值
#define NET_RADI_MAX_TIME_TYPE 2   // 净辐射辐照度最大值
#define NET_RADI_MIN_TIME_TYPE 3   // 净辐射辐照度最小值
#define DIR_RADI_MAX_TIME_TYPE 4   // 直接辐射辐照度最大值
#define SCA_RADI_MAX_TIME_TYPE 5   // 散射辐射辐照度最大值
#define REF_RADI_MAX_TIME_TYPE 6   // 反射辐射辐照度最大值
#define ULT_RADI_MAX_TIME_TYPE 7   // 紫外线辐射辐照度最大值




class Line2OfRadi: public LineOfBufr
{

public:
  // id 为段标识符；count 为段中要素数量


  Line2OfRadi(const string& id="", const unsigned count = 28):m_flag(0), m_maxTime("014194"), m_minTime("014194"), LineOfBufr(id, count) { }

  virtual int FillLine(const string& code, const MyNum& num, const MyStr& str, const char* qc);
  // 和 code 无关的项目，故也无需被回调函数使用。
  int Attachment(const string& filename);
private:
  int m_flag; 
  int m_radiType;  /* 自定义，用于区分最大值出现时的辐射类型*/
  Reaper m_maxTime;  // 获取辐射辐照度最大值出现的时间#时分
  Reaper m_minTime;  // 获取辐射辐照度最小值出现的时间#时分
  
  
};
