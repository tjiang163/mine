#include "stdafx.h"
#include "JtArray.h"


JtArray::JtArray()
{
}


JtArray::~JtArray()
{
}
