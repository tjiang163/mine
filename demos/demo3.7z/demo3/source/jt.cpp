#include "stdafx.h"
#include "jt.h"

using namespace std;
//JT::JT()
//{
//
//}

JT::JT(int nYear, int nMonth, int nDay)
{
	cout << " construct function is called...." << endl;
}

JT::JT()
{
	cout << "default construct function is called...." << endl;
}

JT::~JT()
{

}

