#pragma once
class CJtString
{
public:
	CJtString();
	virtual ~CJtString();
private:
	char* m_StrBuff;
};

