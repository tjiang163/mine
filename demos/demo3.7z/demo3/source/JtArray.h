#pragma once
class JtArray
{
public:
	JtArray();
	~JtArray();
};

