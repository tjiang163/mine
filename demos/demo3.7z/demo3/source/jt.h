#pragma once
class JT
{
public:
	JT();
	JT(int nYear,int nMonth,int nDay);
	virtual ~JT();
protected:
private:
	int _year;
	int _Month;
	int _Day;
};