#include "stdafx.h"
#include "JtString.h"


CJtString::CJtString()
{
}


CJtString::~CJtString()
{
}
