#include "stdafx.h"
#include "JtVector.h"


JtVector::JtVector()
{
}


JtVector::~JtVector()
{
}
