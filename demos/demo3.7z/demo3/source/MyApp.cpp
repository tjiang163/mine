// ConsoleApplication2.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "jt.h"
#include <memory>

struct AllocateMetrics
{
	uint32_t nTotalAllocated = 0;
	uint32_t nTotalFreed = 0;
	void PrintCurMemUsage() {
		uint32_t nSize=nTotalAllocated - nTotalFreed;
		std::cout << "Cur Mem Usage:" << nSize << std::endl;
	}
};

class TA
{
public:
	void operator()()
	{
		std::cout << "thread start...." << std::endl;
		std::cout << "thread end...." << std::endl;
	}
};

template<typename T1, typename T2> T2 \
func(T1 i, T2 ii)
{
	return i + ii;
}

void jt()
{
	std::cout << "thread start...." << std::endl;
	std::cout << "thread end...." << std::endl;
}
static struct AllocateMetrics o_AM;
void* operator new(size_t nSize) noexcept
{
	std::cout << "already new:" << nSize << "Bytes\n";
	o_AM.nTotalAllocated += nSize;
	return std::malloc(nSize);
}
void operator delete(void* m_Obj, size_t size)
{
	std::free(m_Obj);
	o_AM.nTotalAllocated += size;
}

class MyClass
{
public:
	MyClass();
	~MyClass();
	void Disp();

private:
	double x, y;
};

MyClass::MyClass()
{
}

MyClass::~MyClass()
{
}

void MyClass::Disp()
{
	std::cout << x << y << std::endl;
}

int main()
{
	MyClass my;
	my.Disp();
	char arr4[5] = { '1','2','3','4','5' };
	for (int ii = 0; ii < 5; ii++)
	{
		std::cout << arr4[ii] << std::endl;
	}

	JT jj(1, 2, 3);
	char* p;
	std::cout << sizeof(p) << std::endl;
	std::thread obj(jt);
	//obj.detach();
	if (obj.joinable())
		obj.join();
	else
		obj.detach();
	o_AM.PrintCurMemUsage();
	TA tt;
	std::thread obj1(tt);
	obj1.join();
	auto threadLamda = []
	{
		//"Cherno"
		std::cout << "start........." << std::endl;
		std::cout << "end........." << std::endl;
	};
	std::thread lamobj(threadLamda);
	lamobj.join();
	std::cout << "Main End..." << std::endl;
	std::cout << "Main End..." << std::endl;
	JT* aa = new JT[2];
	
	//---------------------------------------------------------------------------
	std::cout << "Class Size "<<sizeof(MyClass) << std::endl;
	std::cout << func(3, 5) << std::endl;
	o_AM.PrintCurMemUsage();

	char ch;
	std::cin.get(ch);

	return 0;
}

