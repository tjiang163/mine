#pragma once
class JtVector
{
public:
	JtVector();
	~JtVector();
};

